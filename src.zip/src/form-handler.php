<?php

$name = $_POST['firstname'];
$name = $_POST['lastname'];
$visitor_email = $_POST['email'];
$phonenumber = $_POST['phonenumber'];
$message = $_POST['message'];


$email_form = 'birdhouse.unaux.com';

$email_subject ='New Form Subject';

$emil_body ="User Name: $name.\n".
          "User Email: $visitor_email.\n".
          "Subject: $phonenumber.\n".
          "User Message: $message.\n";

$to ='mdsalamkhan6912@gmail.com';
$headers ="Form: $email_form \r\n";
$headers . ="Reply-To: $visitor_email \r\n";

mail($to,$email_subject,$emil_body,$headers);
header("Location: contact.html");
 ?>
